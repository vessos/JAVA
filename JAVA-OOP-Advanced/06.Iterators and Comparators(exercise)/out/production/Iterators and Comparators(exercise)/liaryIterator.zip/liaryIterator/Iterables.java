package liaryIterator;

import java.util.Iterator;

public interface Iterables<T> {

    boolean Move();
    void Print();
    boolean HasNext();
    void PrintAll();
}
