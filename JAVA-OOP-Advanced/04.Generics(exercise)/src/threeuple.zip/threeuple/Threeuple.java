package threeuple;


public class Threeuple<T> extends Tuple {
    private T item3;

    public Threeuple(Object item1, Object item2,T item3) {
        super(item1, item2);
        setItem3(item3);

    }

    public T getItem3() {
        return this.item3;
    }

    private void setItem3(T item3) {
        this.item3 = item3;
    }

    @Override
    public String toString() {
        return super.toString() + " -> " + getItem3();
    }
}
