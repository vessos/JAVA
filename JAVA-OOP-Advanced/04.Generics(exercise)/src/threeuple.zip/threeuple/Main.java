package threeuple;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {

    public static void main(String[] args) throws IOException {

        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        String[]line = reader.readLine().split(" ");
        String name = line[0] + " " + line[1];
        Threeuple trl = new Threeuple(name,line[2],line[3]);
        System.out.println(trl);
        String[]line1 = reader.readLine().split(" ");
        boolean isitDrunk=false;
        if(line1[2].equals("drunk")){
            isitDrunk= true;
        }
        Threeuple trl1 = new Threeuple(line1[0],Integer.valueOf(line1[1]),isitDrunk);
        System.out.println(trl1);
        String[]line2 = reader.readLine().split(" ");
        Threeuple trl2= new Threeuple(line2[0],Double.valueOf(line2[1]),line2[2]);
        System.out.println(trl2);


    }
}
