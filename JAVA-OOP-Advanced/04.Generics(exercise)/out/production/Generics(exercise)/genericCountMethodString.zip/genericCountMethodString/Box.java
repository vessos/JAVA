package genericCountMethodString;

/**
 * Created by MARK-Max on 17/03/2017.
 */
public interface Box<T> {
    void addElement(T element);
    void compare(T element);
}
