package threeuple;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {

    public static void main(String[] args) throws IOException {

        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        String[]line = reader.readLine().split(" ");
        String name = line[0] + " " + line[1];
        Threeuple trl = new Threeuple(name,line[2],line[3]);
        System.out.println(trl);
        String[]line1 = reader.readLine().split(" ");
        Threeuple trl1 = new Threeuple(line1[0],Integer.valueOf(line1[1]),line[3]);
        System.out.println(trl1);
        String[]line2 = reader.readLine().split(" ");
        Threeuple trl2= new Threeuple(line1[0],Double.valueOf(line1[1]),line[3]);
        System.out.println(trl2);


    }
}
