package coffeeMashine;

public enum CoffeeType{
    ESPRESSO,LATTE,IRISH;
}

