package createAnnotation;

@Subject(categories = {"Test","Annotation"})
public class Test {
}
