package weekDays;

public class Main {
}
