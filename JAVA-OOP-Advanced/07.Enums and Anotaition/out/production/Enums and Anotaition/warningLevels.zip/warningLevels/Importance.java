package warningLevels;

public enum Importance {
    LOW,NORMAL,MEDIUM,HIGH;
}
