package pr0304Barracks.contracts;

public interface Runnable {
	void run();
}
