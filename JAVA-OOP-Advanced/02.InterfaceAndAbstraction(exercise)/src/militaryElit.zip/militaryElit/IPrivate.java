package militaryElit;

public interface IPrivate {

    Double getSalary();
    String toString();
}
