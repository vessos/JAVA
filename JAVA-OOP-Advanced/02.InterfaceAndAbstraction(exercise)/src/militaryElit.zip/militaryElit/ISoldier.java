package militaryElit;

public interface ISoldier  {
    String getFirstName();
    String getLastName();
    Integer getId();
}
