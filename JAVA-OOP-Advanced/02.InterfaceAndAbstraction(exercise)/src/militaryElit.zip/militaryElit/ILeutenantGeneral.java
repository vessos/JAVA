package militaryElit;

public interface ILeutenantGeneral  {

    void setSoldiers(Private idSoldier);
    String toString();
}
