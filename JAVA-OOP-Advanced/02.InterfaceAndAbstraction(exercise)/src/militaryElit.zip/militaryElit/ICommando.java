package militaryElit;

public interface ICommando  {

    void addMission(Mission mission);
    String toString();
}
