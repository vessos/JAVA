package militaryElit;

public interface ISpecialisedSoldier {

    String getCorps();
    String toString();
}
