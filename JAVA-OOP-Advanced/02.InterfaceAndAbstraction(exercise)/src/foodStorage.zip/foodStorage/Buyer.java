package foodStorage;

public interface Buyer {

    Integer getFood();
    void BuyFood();
}
