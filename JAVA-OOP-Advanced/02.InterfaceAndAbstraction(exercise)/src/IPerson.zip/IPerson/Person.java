package IPerson;

public interface Person {
    String getName();
    Integer getAge();
}
