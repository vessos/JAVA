package mood3;

public interface Character {

    void generateHashPasword();

}

