package birthdayCelebrations;

public class Robot  {
    private String model;
    private String id;

    public Robot(String id,String model) {
        this.id = id;
        this.model = model;
    }
}
