package birthdayCelebrations;

public class Pet extends BasePerson {
    public Pet(String name,String birthday) {
        super(name,birthday);
    }

}
