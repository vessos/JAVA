package birthdayCelebrations;

public interface Person {

    String getBirthDay();
    boolean checkBirthday(String num);
}
