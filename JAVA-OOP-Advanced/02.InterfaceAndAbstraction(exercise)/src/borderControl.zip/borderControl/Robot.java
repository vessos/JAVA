package borderControl;

public class Robot extends BasePerson {
    private String model;

    public Robot(String id,String model) {
        super(id);
        this.model = model;
    }
}
