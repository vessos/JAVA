package borderControl;

public interface Person {

    String getId();
    boolean checkId(String num);
}
