package telephony;

/**
 * Created by MARK-Max on 19/03/2017.
 */
public interface Browse {

    String browseInTheWWW(String site);
}
