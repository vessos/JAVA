package multiplyImplementation;

public interface Identifiable {
    String getId();
}
