package multiplyImplementation;

public interface Birthable {
    String getBirthdate();
}
