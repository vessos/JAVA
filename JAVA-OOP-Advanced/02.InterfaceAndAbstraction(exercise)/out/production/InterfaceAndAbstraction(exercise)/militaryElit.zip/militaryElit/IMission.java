package militaryElit;

public interface IMission {

    boolean isItMission();
    void completeMission();
    String getState();
    String getCodeName();
    String toString();
}
