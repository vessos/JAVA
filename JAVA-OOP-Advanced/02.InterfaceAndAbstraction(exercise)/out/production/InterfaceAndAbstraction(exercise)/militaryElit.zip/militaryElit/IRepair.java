package militaryElit;


public interface IRepair {
    String getPartName();
    Integer getHoursWorked();
    String toString();
}
