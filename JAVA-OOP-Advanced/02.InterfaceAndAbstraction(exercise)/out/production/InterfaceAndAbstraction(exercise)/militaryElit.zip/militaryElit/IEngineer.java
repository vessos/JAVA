package militaryElit;

public interface IEngineer {

    void addRepairPart(Repair repair);
    String toString();
}
