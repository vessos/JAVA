package militaryElit;

public interface ISpy {
    String toString();
}
