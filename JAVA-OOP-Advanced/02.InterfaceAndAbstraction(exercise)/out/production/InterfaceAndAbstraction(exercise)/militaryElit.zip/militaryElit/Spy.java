package militaryElit;

public class Spy extends Soldier implements ISpy {
    private Integer codeNumber;
    public Spy(Integer id, String firstName, String lastName,Integer codeNumber) {
        super(id, firstName, lastName);
        this.codeNumber = codeNumber;
    }


    @Override
    public String toString() {
        return String.format("Name: %s %s Id: %d\nCode Number: %s",
                super.getFirstName(),super.getLastName(),super.getId(),this.codeNumber).trim();
    }

}
