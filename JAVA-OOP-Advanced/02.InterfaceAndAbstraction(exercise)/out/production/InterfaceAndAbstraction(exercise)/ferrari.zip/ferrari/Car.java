package ferrari;

public interface Car {

    String useBrackes();
    String pushAndTheGasPedal();

}
