package createCustomAnotation;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {
    public static void main(String[] args) throws IOException {

        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        String line = "";
        Class weapon = Weapon.class;
        Custom custom = (Custom) weapon.getAnnotation(Custom.class);
        while (!"END".equals(line = reader.readLine())) {
            switch (line) {
                case "Author":
                    System.out.println("Author: " + custom.author());
                    break;
                case "Revision":
                    System.out.println("Revision: " + custom.revision());
                    break;
                case "Description":
                    System.out.println("Class description: " + custom.description());
                    break;
                case "Reviewers":
                    System.out.println("Reviewers: " + String.join(", ",custom.reviewers()));
                    break;
            }
        }
    }
}
