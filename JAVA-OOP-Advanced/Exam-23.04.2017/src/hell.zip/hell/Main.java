package hell;

import hell.interfaces.Hero;
import hell.interfaces.Item;
import hell.models.Heroes.Assassin;
import hell.models.Heroes.Barbarian;
import hell.models.Heroes.Wizard;
import hell.models.Items.CommonItem;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.LinkedHashMap;

public class Main {
    public static void main(String[] args) throws IOException {

        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        String line = "";

        while("Quit".equals(line = reader.readLine())){

            String[] input = line.split(" ");
            String command = input[0];
            LinkedHashMap<String,Hero>heroes = new LinkedHashMap<>();
            switch(command){
                case"Hero":
                    Hero hero = null;
                    String type = input[2];
                    if (type.equals("Barbarian")){
                        hero = new Barbarian(input[1]);
                    }else if(type.equals("Assassin")){
                        hero = new Assassin(input[1]);
                    }else{
                        hero = new Wizard(input[1]);
                    }
                    heroes.put(input[1],hero);
                    break;
                case"Item":
                    Item item = new CommonItem(input[1],Integer.valueOf(3),Integer.valueOf(4),Integer.valueOf(5),Integer.valueOf(6)
                    ,Integer.valueOf(7));
                    for (String s : heroes.keySet()) {
                        if(s.equals(input[2])){

                        }
                    }
                    break;
                case"Recipe":
                    break;
                case"Inspect":
                    break;
            }
        }
    }
}