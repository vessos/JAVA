package hell.models.Heroes;

public class Assassin extends AbstractHeroes {

    private static final int STRENGTH = 25;
    private static final int AGILITY = 100;
    private static final int INTELLIGENCE = 15;
    private static final int HIT_POINTS = 150;
    private static final int DAMAGE = 300;

    public Assassin(String name) {
        super(name);
        super.setStrength(STRENGTH);
        super.setAgility(AGILITY);
        super.setIntelligence(INTELLIGENCE);
        super.setHitPoints(HIT_POINTS);
        super.setDamage(DAMAGE);
    }
}
