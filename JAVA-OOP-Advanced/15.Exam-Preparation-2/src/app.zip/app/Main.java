package app;

import app.models.strategies.RecyclableGarbageDisposableStrategy;
import app.models.strategies.StorableGarbageDisposableStrategy;
import app.models.wastes.BurnableGarbage;
import app.models.strategies.BurnableGarbageDisposableStrategy;
import app.models.wastes.RecyclableGarbage;
import app.models.wastes.StorableGarbage;
import app.waste_disposal.DefaultGarbageProcessor;
import app.waste_disposal.annotations.Burnable;
import app.waste_disposal.annotations.Recyclable;
import app.waste_disposal.annotations.Storable;
import app.waste_disposal.contracts.GarbageProcessor;
import app.waste_disposal.contracts.ProcessingData;
import app.waste_disposal.contracts.Waste;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {

    static  GarbageProcessor garbageProcessor = new DefaultGarbageProcessor();
    static double energy = 0;
    static double capital = 0;

    public static void main(String[] args) throws IOException {




        garbageProcessor.getStrategyHolder()
                .addStrategy(Burnable.class,new BurnableGarbageDisposableStrategy());
        garbageProcessor.getStrategyHolder()
                .addStrategy(Recyclable.class,new RecyclableGarbageDisposableStrategy());
        garbageProcessor.getStrategyHolder()
                .addStrategy(Storable.class,new StorableGarbageDisposableStrategy());

        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        String line = "";

        while(!"TimeToRecycle".equals(line = reader.readLine())){

            String[]cmdArgs = line.split("\\s+");
            String cmdType = cmdArgs[0];
            switch (cmdType){
                case"ProcessGarbage":
                    processGarbage(cmdArgs[1]);
                    break;
                case"Status":
                    System.out.println(String.format("Energy: %.2f Capital: %.2f",energy,capital));
                    break;
                default:
                    System.out.println("Invalid command");
            }
        }
        
    }

    private static void processGarbage(String parameters) {

        String[] args = parameters.split("\\|");
        String name = args[0];
        Double weight = Double.valueOf(args[1]);
        Double volumePerKg = Double.valueOf(args[2]);
        String type = args[3];

        Waste waste = null;
        switch (type){
            case"Recyclable":
                waste = new RecyclableGarbage(name,weight,volumePerKg);
                break;
            case"Burnable":
                waste = new BurnableGarbage(name,weight,volumePerKg);
                break;
            case"Storable":
                waste = new StorableGarbage(name,weight,volumePerKg);
                break;

        }

        ProcessingData processingData = garbageProcessor.processWaste(waste);
        energy+=processingData.getEnergyBalance();
        capital+=processingData.getCapitalBalance();
        System.out.println(String.format("%.2f kg of %s successfully processed!",weight,name));
    }
}
