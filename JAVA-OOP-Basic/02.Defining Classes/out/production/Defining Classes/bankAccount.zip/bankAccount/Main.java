package bankAccount;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;

public class Main {
    public static void main(String[] args) throws IOException {

        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        HashMap<Integer, BankAccount>accounts = new HashMap<>();
        String command = reader.readLine();
        while(!command.equals("End")){

            String[]commandsArgs = command.split(" ");
            String commandType = commandsArgs[0];

            switch(commandType){
                case "Create":
                    executeCreateCommand(accounts, commandsArgs[1]);
                    break;
                case "Deposit":
                    executeDepositCommand(accounts,commandsArgs);
                    break;
                case "Withdraw":
                    executeWithdrawCommand(accounts,commandsArgs);
                    break;
                case "Print":
                    executePrintCommand(accounts,commandsArgs);
                    break;

            }
            command = reader.readLine();
        }
    }

    private static void executeCreateCommand(HashMap<Integer, BankAccount> accounts, String commandsArg) {
        int id = Integer.valueOf(commandsArg);
        if (accounts.containsKey(id)) {
            System.out.println("Account already exists");
        }else{
           BankAccount account = new BankAccount();
           account.setId(id);
           accounts.put(id,account);
        }
    }
    private static void executeDepositCommand(HashMap<Integer,BankAccount>accounts,String[] commandsArgs){
        Integer id = Integer.valueOf(commandsArgs[1]);
        Double amount = Double.valueOf(commandsArgs[2]);

        if(!accounts.containsKey(id)){
            System.out.println("Account does not exist");
            return;
        }
        try{
            accounts.get(id).deposit(amount);
        }catch(IllegalArgumentException iee){
            System.out.println(iee.getMessage());
        }

    }
    private static void executeWithdrawCommand(HashMap<Integer,BankAccount>accounts,String[]commandsArgs){

        Integer id = Integer.valueOf(commandsArgs[1]);
        Double amount = Double.valueOf(commandsArgs[2]);

        if(!accounts.containsKey(id)){
            System.out.println("Account does not exist");
            return;
        }
        try{
            accounts.get(id).withdraw(amount);
        }catch(IllegalStateException iee){
            System.out.println(iee.getMessage());
        }

    }
    private static  void executePrintCommand(HashMap<Integer,BankAccount>accounts,String[]commandsArgs){
        Integer id = Integer.valueOf(commandsArgs[1]);

        if(!accounts.containsKey(id)){
            System.out.println("Account does not exist");
            return;
        }
        BankAccount account = accounts.get(id);
        System.out.printf("Account %s, balance %.2f%n",account,account.getBalance());

    }
}
