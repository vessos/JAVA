package catLady;

public abstract class Cat {

    String name;

    public Cat(String name) {
        this.name = name;
    }
}
