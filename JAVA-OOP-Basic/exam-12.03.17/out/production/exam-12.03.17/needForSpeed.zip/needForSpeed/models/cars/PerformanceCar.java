package needForSpeed.models.cars;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class PerformanceCar extends Car {

    private List<String> addOns;

    public PerformanceCar(String brand, String model, int yearOfProduction, int horsepower, int acceleration, int suspension, int durability) {
        super(brand, model, yearOfProduction, horsepower, acceleration, suspension, durability);
        super.setHorsepower(horsepower+(horsepower*50)/100);
        super.setSuspension(suspension-(suspension*25)/100);
        this.addOns = new ArrayList<>();

    }

    public List<String> getAddOns() {
        return Collections.unmodifiableList(this.addOns);
    }

    public void addOns(String type){
        this.addOns.add(type);
    }

    @Override
    public String toString() {

        String print = String.format("%s %s %d\n%d HP, 100 m/h in %d s\n%d Suspension force, %d Durability Add-ons: %d",
                super.getBrand(),super.getModel(),super.getYearOfProduction(),
                super.getHorsepower(),super.getAcceleration(),super.getSuspension(),super.getDurability(),null);
        return print;
    }


}
