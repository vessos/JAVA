package needForSpeed.models.cars;


public class ShowCar extends Car {

    private final static int STARS=0;

    private int stars;
    public ShowCar(String brand, String model, int yearOfProduction, int horsepower, int acceleration, int suspension, int durability) {
        super(brand, model, yearOfProduction, horsepower, acceleration, suspension, durability);
        this.stars = STARS;
    }

    public int getStars() {
        return this.stars;
    }
    public void addStars(int stars){
        this.stars+=stars;
    }

    @Override
    public String toString() {
        String print = String.format("%s %s %d\n%d HP, 100 m/h in %d s\n%d Suspension force, %d Durability %d *",
                super.getBrand(),super.getModel(),super.getYearOfProduction(),
                super.getHorsepower(),super.getAcceleration(),super.getSuspension(),super.getDurability(),this.getStars());
        return print;
    }
}
