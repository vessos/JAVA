package needForSpeed;

import needForSpeed.models.CarManager;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {
    public static void main(String[] args) throws IOException {

        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        String line = "";
        CarManager carManager = new CarManager();

        while(!"Cops Are Here".equals(line = reader.readLine())){

            String[] input = line.split(" ");
            String command = input[0];
            switch(command){
                case"register":
                    int id = Integer.valueOf(input[1]);
                    String type = input[2];
                    String brand = input[3];
                    String model = input[4];
                    int years = Integer.parseInt(input[5]);
                    int horcepower = Integer.parseInt(input[6]);
                    int acceleration = Integer.parseInt(input[7]);
                    int suspention = Integer.parseInt(input[8]);
                    int durability = Integer.parseInt(input[9]);
                    carManager.register(id,type,brand,model,years,horcepower,acceleration
                    ,suspention,durability);
                    break;
                case"open":
                    int ID = Integer.valueOf(input[1]);
                    String typeofRace = input[2];
                    int length = Integer.valueOf(input[3]);
                    String route = input[4];
                    int prizepool = Integer.valueOf(input[5]);
                    carManager.open(ID,typeofRace,length,route,prizepool);
                    break;
                case"participate":
                    int carId = Integer.valueOf(input[1]);
                    int raceId = Integer.valueOf(input[2]);
                    carManager.participate(carId,raceId);
                    break;
                case"check":
                    System.out.println(carManager.check(Integer.valueOf(input[1])));
                    break;
                case"park":
                    carManager.park(Integer.valueOf(input[1]));
                    break;
                case"unpark":
                    carManager.unpark(Integer.valueOf(input[1]));
                    break;
                case"tune":
                    int tuneIndex = Integer.valueOf(input[1]);
                    String addOnn = input[2];
                    carManager.tune(tuneIndex,addOnn);
                    break;
                case"start":
                    System.out.println(carManager.start(Integer.valueOf(input[1])));
                    break;

            }
        }
    }
}
