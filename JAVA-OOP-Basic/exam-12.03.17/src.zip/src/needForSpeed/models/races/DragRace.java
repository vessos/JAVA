package needForSpeed.models.races;

public class DragRace extends Race {


    public DragRace(int length, String route, int prizePool) {
        super(length, route, prizePool);
    }




}
