package animals;


public class Kittens extends Cat {
    public Kittens(String name, int age, String gender) {
        super(name, age, gender);
    }

    @Override
    protected void setGender(String gender) {
        if(!"Female".equals(gender)){
            throw new IllegalArgumentException("Invalid input!");
        }
        super.setGender(gender);
    }


    @Override
    protected String produceSound() {
        return "Miau";
    }
}
